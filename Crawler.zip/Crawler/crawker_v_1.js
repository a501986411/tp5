/**
 * Created by knight on 2017/7/14.
 */
//引入http模块
var http = require('http');
var request = require('request');
var fs = require('fs');
var mysql = require('mysql');
const cheerio = require('cheerio');
var url = 'http://www.meet99.com';
var db_config = {
    host     : 'localhost',
    user     : 'root',
    password : '',
    database : 'chl_address'
};
//连接数据库
var db = linkDb(db_config);
function linkDb(config)
{
    var db = mysql.createConnection(config);
    console.log('test link db...');
    db.connect(function(err){
        if (err) {
            console.error('error connecting db: ' + err.stack);
            return;
        }
        console.log('connected as id ' + db.threadId);
    });
    return db;
}


http.createServer(function(req,res){
    getPageData(url+'/map.html',1,0,'');
}).listen(8010);

function getPageData(url,level,pid,path)
{
    console.log('get URL:'+url);
    //var options = {
    //   'hostname':'www.meet99.com',
    //    port:80,
    //    path:address,
    //    method:'GET',
    //    headers:{
    //        'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    //         'Accept-Encoding':'gzip, deflate',
    //         'Accept-Language':'zh-CN,zh;q=0.8',
    //         'Cache-Control':'no-cache',
    //         'Connection':'keep-alive',
    //         'Cookie':'V=2101759313-1499764019-0-1500024403-3-74-0-7469-0-0-0-3b7cfd-; s=1366x397_1366x768; Hm_lvt_9ee138b42a64fd1fee727659e189c033=1500006702,1500006736,1500006772,1500006828; Hm_lpvt_9ee138b42a64fd1fee727659e189c033=1500024415',
    //         'Host':'www.meet99.com',
    //         'Pragma':'no-cache',
    //         'Referer':url,
    //         'Upgrade-Insecure-Requests':1,
    //         'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36',
    //    }
    //}
    http.get(url,function(content){
        var html = '';
        content.on('data',function(data){
            console.log(data);
            html += data;
        });
        content.on('end',function(){
            filtterHtml(html,level,pid,path);
        });
    }).on('error',function(e){
        console.log('ERROR:'+e);
    });
}


//爬取 大区 与 省/直辖市 的信息
function filtterHtml(html,level,pid,path)
{
    var $ = cheerio.load(html);
    $('.selected').next('ul').find('li').each(function(){
        var $li = $(this);
        var data = {};
        var id = $li.attr('id');
        data.pid = pid;
        data.path_line = path;
        data.level = level;
        if(id == undefined){ //大区
            data.name = $li.find('span').text();
            $li.remove();
        } else { //不是大区
            data.name = $li.find('a').text();
            data.en_name = id;
            data.child_href = $li.find('a').attr('href');
        }
        db.beginTransaction(function(err) {
            if (err) { throw err; }
            db.query('INSERT INTO address_country_address SET ?',
                data, function (error, results, fields) {
                    if (error) {
                        return db.rollback(function() {
                            throw error;
                        });
                    }
                    level++;
                    pid = results.insertId;
                    db.query('select * from address_country_address where id=?',results.insertId,function(error, results, fields){
                        path += results.path_line+'-';
                    });
                    if(id && $li.next('ul') !== undefined){
                        var _url = url+data.child_href;
                        getPageData(_url,level,pid,path);
                    }else{
                        //filtterHtml(html,level,pid,path);
                    }
                    db.commit(function(err){
                        if (err) {
                            return db.rollback(function() {
                                throw err;
                            });
                        }
                        console.log('SUCCESS---'+JSON.stringify(data));
                    })
                });
        });
    });
}


