/**
 * Created by knight on 2017/7/14.
 */
//����httpģ��
var http = require('http');
var request = require('request');
var fs = require('fs');
var mysql = require('mysql');
const cheerio = require('cheerio');
var url = 'http://www.meet99.com/map';
var db_config = {
    host     : 'localhost',
    user     : 'root',
    password : '',
    database : 'chl_address'
};
//�������ݿ�
var db = linkDb(db_config);
function linkDb(config)
{
    var db = mysql.createConnection(config);
    console.log('test link db...');
    db.connect(function(err){
        if (err) {
            console.error('error connecting db: ' + err.stack);
            return;
        }
        console.log('connected as id ' + db.threadId);
    });
    return db;
}

function getChildren()
{

}

/**
 * �������ݿ�
 * @param address
 */
function saveData(address,getChildren){
    address.forEach(function(value,key){
        db.beginTransaction(function(err) {
            if (err) { throw err; }
            db.query('INSERT INTO address_country_address SET ?',
                {name:value.name}, function (error, results, fields) {
                    if (error) {
                        return db.rollback(function() {
                            throw error;
                        });
                    }

                    if(value.children){
                        value.children.forEach(function(val,k){
                            var data = {
                                name:val.name,
                                pid:results.insertId,
                                path_line:results.insertId+'-',
                                level:2,
                                child_href:val.child_href,
                                en_name:val.en_name
                            }
                            db.query('insert INTO address_country_address set ?',
                                data,function(err, ret, flds){
                                    if (err) {
                                        return db.rollback(function() {
                                            throw err;
                                        });
                                    }
                                });

                            db.commit(function(err) {
                                if (err) {
                                    return db.rollback(function() {
                                        throw err;
                                    });
                                }
                                console.log('success!');
                            });
                        });
                    }
                });
        });
    });
    getChildren && getChildren();
}

http.createServer(function(req,res){
    http.get(url,function(content){
        var html = '';
        content.on('data',function(data){
            html += data;
        });
        content.on('end',function(){
            var address = filtterHtml(html);
            //�������ݿ�
            saveData(address,getChildren);
        });
    }).on('error',function(){
        console.log('��ȡ���ݴ���');
    });
}).listen(8010);

//��ȡ ���� �� ʡ/ֱϽ�� ����Ϣ
function filtterHtml(html)
{
    var $ = cheerio.load(html);
    var address = [];
    $('.selected').next('ul').find('.open').each(function(){
        var content = {};
        var children = [];
        content.name = $(this).find('span').text();
        $(this).find('.hasChildren').each(function(){
            var child = {};
            child.en_name = $(this).attr('id');
            child.name = $(this).find('a').text();
            child.child_href= $(this).find('a').attr('href');
            children.push(child);
        });
        content.children = children;
        address.push(content);
    })
    return address;
}


